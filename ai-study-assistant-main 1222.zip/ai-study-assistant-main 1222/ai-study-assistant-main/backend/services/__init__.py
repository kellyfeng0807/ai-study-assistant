"""
Services package
"""

from .ai_service import ai_service

__all__ = ['ai_service']
