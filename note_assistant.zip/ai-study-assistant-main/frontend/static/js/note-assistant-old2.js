/**
 * Note Assistant Page JavaScript - 完整版
 * 包含语音识别、笔记生成、列表显示等功能
 */

class NoteAssistantManager {
    constructor() {
        // 录音相关
        this.isRecording = false;
        this.recordingTime = 0;
        this.timerInterval = null;
        this.mediaRecorder = null;
        this.audioChunks = [];
        
        // 语音识别相关
        this.recognition = null;
        this.transcribedText = '';
        this.isRecognizing = false;
        
        // 初始化
        this.initSpeechRecognition();
        this.init();
    }
    
    init() {
        this.bindEventListeners();
        this.loadRecentNotes();
        console.log('Note Assistant initialized with speech recognition');
    }
    
    /**
     * 初始化语音识别（Web Speech API）
     */
    initSpeechRecognition() {
        // 检查浏览器支持
        const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
        
        if (!SpeechRecognition) {
            console.warn('浏览器不支持语音识别');
            Utils.showNotification('您的浏览器不支持语音识别功能', 'warning');
            return;
        }
        
        this.recognition = new SpeechRecognition();
        this.recognition.continuous = true;           // 持续识别
        this.recognition.interimResults = true;       // 显示临时结果
        this.recognition.lang = 'zh-CN';              // 中文识别
        this.recognition.maxAlternatives = 1;
        
        // ✨ 新增：降低识别要求
        if (this.recognition.audioContext) {
            this.recognition.audioContext.sampleRate = 16000;  // 降低采样率
        }
        
        // 识别结果事件
        this.recognition.onresult = (event) => {
            let interimTranscript = '';
            let finalTranscript = '';
            
            for (let i = event.resultIndex; i < event.results.length; i++) {
                const transcript = event.results[i][0].transcript;
                if (event.results[i].isFinal) {
                    finalTranscript += transcript;
                } else {
                    interimTranscript += transcript;
                }
            }
            
            // 更新转录文本
            if (finalTranscript) {
                this.transcribedText += finalTranscript + '。';
                console.log('识别文字:', finalTranscript);
                
                // ✨ 关键：自动填充到文本输入框！
                this.fillTextToInputBox(this.transcribedText);
            }
            
            // 更新显示
            this.updateTranscriptionDisplay(this.transcribedText, interimTranscript);
        };
        
        // 错误处理（优化版：忽略 no-speech 错误）
        this.recognition.onerror = (event) => {
            console.log('语音识别状态:', event.error);
            
            // 忽略 no-speech 错误（这是最常见的错误，不需要提示用户）
            if (event.error === 'no-speech') {
                console.log('💡 提示：语音识别未检测到声音，建议使用下方的文本输入框');
                return;  // 直接返回，不显示任何提示
            }
            
            // 忽略 aborted 错误（用户主动停止）
            if (event.error === 'aborted') {
                return;
            }
            
            // 其他严重错误才提示用户
            if (event.error === 'audio-capture') {
                Utils.showNotification('无法访问麦克风，请检查权限设置', 'error');
            } else if (event.error === 'not-allowed') {
                Utils.showNotification('麦克风权限被拒绝', 'error');
            } else {
                console.error('语音识别错误:', event.error);
            }
        };
        
        // 结束事件
        this.recognition.onend = () => {
            this.isRecognizing = false;
            console.log('语音识别已停止');
        };
        
        // 开始事件
        this.recognition.onstart = () => {
            this.isRecognizing = true;
            console.log('语音识别已开始');
        };
    }
    
    bindEventListeners() {
        const recordBtn = document.getElementById('recordBtn');
        const uploadBtn = document.getElementById('uploadBtn');
        const transcribeBtn = document.getElementById('transcribeBtn');
        const manualGenerateBtn = document.getElementById('manualGenerateBtn');
        
        if (recordBtn) {
            recordBtn.addEventListener('click', () => this.toggleRecording());
        }
        
        if (uploadBtn) {
            uploadBtn.addEventListener('click', () => this.uploadAudio());
        }
        
        if (transcribeBtn) {
            transcribeBtn.addEventListener('click', () => this.generateNote());
        }
        
        // ✨ 新增：手动输入文字生成笔记
        if (manualGenerateBtn) {
            manualGenerateBtn.addEventListener('click', () => this.generateNoteFromManualInput());
        }
    }
    
    /**
     * 切换录音状态（同时启动语音识别）
     */
    async toggleRecording() {
        if (this.isRecording) {
            this.stopRecording();
        } else {
            await this.startRecording();
        }
    }
    
    /**
     * 开始录音和语音识别
     */
    async startRecording() {
        try {
            // 请求麦克风权限
            const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
            
            // 初始化 MediaRecorder（用于录音）
            this.mediaRecorder = new MediaRecorder(stream);
            this.audioChunks = [];
            
            this.mediaRecorder.ondataavailable = (event) => {
                this.audioChunks.push(event.data);
            };
            
            this.mediaRecorder.onstop = () => {
                const audioBlob = new Blob(this.audioChunks, { type: 'audio/wav' });
                console.log('录音完成:', audioBlob.size, 'bytes');
            };
            
            // 开始录音
            this.mediaRecorder.start();
            this.isRecording = true;
            this.recordingTime = 0;
            this.transcribedText = '';  // 清空之前的转录
            
            // 启动语音识别
            if (this.recognition) {
                try {
                    this.recognition.start();
                    console.log('语音识别已启动');
                } catch (e) {
                    console.warn('语音识别启动失败:', e);
                }
            }
            
            this.updateRecordingUI();
            this.startTimer();
            
            Utils.showNotification('录音已开始（建议使用下方文本输入框）', 'success');
        } catch (error) {
            console.error('无法启动录音:', error);
            Utils.showNotification('无法访问麦克风，请检查权限设置', 'error');
        }
    }
    
    /**
     * 停止录音和语音识别
     */
    stopRecording() {
        // 停止录音
        if (this.mediaRecorder && this.isRecording) {
            this.mediaRecorder.stop();
            this.mediaRecorder.stream.getTracks().forEach(track => track.stop());
        }
        
        // 停止语音识别
        if (this.recognition && this.isRecognizing) {
            try {
                this.recognition.stop();
            } catch (e) {
                console.warn('停止语音识别失败:', e);
            }
        }
        
        this.isRecording = false;
        this.stopTimer();
        this.updateRecordingUI();
        
        // 显示提示信息
        if (this.transcribedText && this.transcribedText.length > 0) {
            Utils.showNotification(`✅ 识别完成！共 ${this.transcribedText.length} 字已填充到下方输入框`, 'success');
            console.log('最终识别文字:', this.transcribedText);
        } else {
            Utils.showNotification('⚠️ 未识别到语音，请使用下方文本输入框手动输入', 'warning');
        }
    }
    
    startTimer() {
        this.timerInterval = setInterval(() => {
            this.recordingTime++;
            this.updateTimeDisplay();
        }, 1000);
    }
    
    stopTimer() {
        if (this.timerInterval) {
            clearInterval(this.timerInterval);
            this.timerInterval = null;
        }
    }
    
    updateTimeDisplay() {
        const minutes = Math.floor(this.recordingTime / 60);
        const seconds = this.recordingTime % 60;
        const timeDisplay = document.querySelector('.recording-time');
        if (timeDisplay) {
            timeDisplay.textContent = `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
        }
    }
    
    updateRecordingUI() {
        const recordBtn = document.getElementById('recordBtn');
        const statusDisplay = document.querySelector('.recording-status');
        const transcribeBtn = document.getElementById('transcribeBtn');
        
        if (recordBtn) {
            if (this.isRecording) {
                recordBtn.classList.add('recording');
                recordBtn.innerHTML = '<i class="fas fa-stop"></i>';
            } else {
                recordBtn.classList.remove('recording');
                recordBtn.innerHTML = '<i class="fas fa-microphone"></i>';
            }
        }
        
        if (statusDisplay) {
            statusDisplay.textContent = this.isRecording ? 'Recording...' : 'Ready to record';
        }
        
        if (transcribeBtn) {
            // 只有当有识别文字时才启用按钮
            transcribeBtn.disabled = this.isRecording || !this.transcribedText;
        }
    }
    
    /**
     * 更新转录文本显示（可选）
     */
    updateTranscriptionDisplay(finalText, interimText) {
        // 更新按钮状态
        const transcribeBtn = document.getElementById('transcribeBtn');
        if (transcribeBtn && finalText) {
            transcribeBtn.disabled = false;
        }
        
        // ✨ 关键：自动填充到文本输入框
        this.fillTextToInputBox(finalText);
    }
    
    /**
     * ✨ 新增：将识别的文字填充到文本输入框
     */
    fillTextToInputBox(text) {
        if (!text) return;
        
        const textarea = document.getElementById('manualTextInput');
        if (textarea) {
            textarea.value = text;
            
            // 更新字数统计
            const counter = document.getElementById('textCounter');
            if (counter) {
                const count = text.trim().length;
                counter.textContent = count + ' 字';
                
                // 根据字数改变颜色
                if (count < 10) {
                    counter.style.color = 'hsl(var(--muted-foreground))';
                } else if (count < 50) {
                    counter.style.color = 'hsl(45 93% 47%)';
                } else {
                    counter.style.color = 'hsl(142 76% 36%)';
                }
            }
            
            // 滚动到文本框位置（让用户看到）
            textarea.scrollIntoView({ behavior: 'smooth', block: 'center' });
            
            // 闪烁提示效果
            textarea.style.transition = 'background-color 0.3s';
            textarea.style.backgroundColor = '#fff3cd';
            setTimeout(() => {
                textarea.style.backgroundColor = '';
            }, 500);
            
            console.log('✅ 文字已自动填充到输入框，长度:', count);
        }
    }
    
    /**
     * 上传音频文件（备用方案）
     */
    uploadAudio() {
        // 创建文件选择器
        const input = document.createElement('input');
        input.type = 'file';
        input.accept = 'audio/*';
        
        input.onchange = async (e) => {
            const file = e.target.files[0];
            if (!file) return;
            
            console.log('选择的音频文件:', file.name);
            Utils.showNotification('上传功能暂未实现，请使用录音功能', 'info');
        };
        
        input.click();
    }
    
    /**
     * 生成笔记（调用后端 API）
     */
    async generateNote() {
        // 检查是否有识别文字
        if (!this.transcribedText || this.transcribedText.length < 10) {
            Utils.showNotification('识别内容太短，请录制更多内容', 'warning');
            return;
        }
        
        try {
            Utils.showNotification('AI 正在生成笔记...', 'info');
            
            // 调用后端 API
            const result = await this.callGenerateAPI(this.transcribedText);
            
            if (result && result.success) {
                Utils.showNotification('笔记生成成功！', 'success');
                console.log('生成的笔记:', result.notes);
                
                // 显示笔记
                this.displayGeneratedNote(result.notes);
                
                // 刷新笔记列表
                setTimeout(() => this.loadRecentNotes(), 500);
            } else {
                throw new Error(result?.error || '生成笔记失败');
            }
        } catch (error) {
            console.error('生成笔记错误:', error);
            Utils.showNotification('生成笔记失败: ' + error.message, 'error');
        }
    }
    
    /**
     * 调用后端生成笔记 API
     */
    async callGenerateAPI(text, subject = '通用') {
        try {
            const response = await fetch('http://localhost:5000/api/note/generate', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    text: text,
                    subject: subject
                })
            });
            
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            
            return await response.json();
        } catch (error) {
            console.error('API 调用失败:', error);
            throw error;
        }
    }
    
    /**
     * 显示生成的笔记（弹窗或模态框）
     */
    displayGeneratedNote(noteData) {
        // 创建模态框显示笔记
        const modal = document.createElement('div');
        modal.className = 'note-modal';
        modal.innerHTML = `
            <div class="note-modal-content">
                <div class="note-modal-header">
                    <h3>${noteData.title || '生成的笔记'}</h3>
                    <button class="close-button" onclick="this.closest('.note-modal').remove()">×</button>
                </div>
                <div class="note-modal-body">
                    <div class="note-section">
                        <h4>📚 科目</h4>
                        <p>${noteData.subject}</p>
                    </div>
                    
                    <div class="note-section">
                        <h4>🔑 关键点</h4>
                        <ul>
                            ${noteData.key_points.map(point => `<li>${point}</li>`).join('')}
                        </ul>
                    </div>
                    
                    ${noteData.examples && noteData.examples.length > 0 ? `
                    <div class="note-section">
                        <h4>💡 示例</h4>
                        <ul>
                            ${noteData.examples.map(example => `<li>${example}</li>`).join('')}
                        </ul>
                    </div>
                    ` : ''}
                    
                    <div class="note-section">
                        <h4>📝 总结</h4>
                        <p>${noteData.summary}</p>
                    </div>
                    
                    ${noteData.tags && noteData.tags.length > 0 ? `
                    <div class="note-section">
                        <h4>🏷️ 标签</h4>
                        <div class="note-tags">
                            ${noteData.tags.map(tag => `<span class="note-tag">${tag}</span>`).join('')}
                        </div>
                    </div>
                    ` : ''}
                </div>
                <div class="note-modal-footer">
                    <button class="button-outline" onclick="this.closest('.note-modal').remove()">关闭</button>
                    <button class="button-primary" onclick="window.print()">打印</button>
                </div>
            </div>
        `;
        
        document.body.appendChild(modal);
        
        // 点击背景关闭
        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                modal.remove();
            }
        });
    }
    
    /**
     * 加载最近的笔记列表
     */
    async loadRecentNotes() {
        try {
            const response = await fetch('http://localhost:5000/api/note/list?limit=3');
            const data = await response.json();
            
            if (data.success && data.notes.length > 0) {
                this.renderNotesList(data.notes);
            }
        } catch (error) {
            console.error('加载笔记列表失败:', error);
        }
    }
    
    /**
     * 渲染笔记列表
     */
    renderNotesList(notes) {
        const notesGrid = document.querySelector('.notes-grid');
        if (!notesGrid) return;
        
        notesGrid.innerHTML = notes.map(note => `
            <div class="note-card">
                <div class="note-header">
                    <span class="note-subject">${note.subject}</span>
                    <span class="note-date">${note.date}</span>
                </div>
                <h4 class="note-title">${note.title}</h4>
                <p class="note-excerpt">${note.preview}</p>
                <div class="note-footer">
                    <span class="note-meta">ID: ${note.id}</span>
                    <button class="button-outline" onclick="noteManager.viewNoteDetail(${note.id})">View</button>
                </div>
            </div>
        `).join('');
    }
    
    /**
     * 查看笔记详情
     */
    async viewNoteDetail(noteId) {
        try {
            const response = await fetch(`http://localhost:5000/api/note/${noteId}`);
            const data = await response.json();
            
            if (data.success) {
                this.displayGeneratedNote(data.note.content);
            }
        } catch (error) {
            console.error('加载笔记详情失败:', error);
            Utils.showNotification('加载笔记失败', 'error');
        }
    }
    
    /**
     * ✨ 新增：从手动输入的文字生成笔记
     */
    async generateNoteFromManualInput() {
        const textarea = document.getElementById('manualTextInput');
        
        if (!textarea) {
            console.error('找不到文本输入框');
            return;
        }
        
        const text = textarea.value.trim();
        
        // 验证输入
        if (!text) {
            alert('⚠️ 请输入一些内容');
            textarea.focus();
            return;
        }
        
        if (text.length < 10) {
            alert('⚠️ 内容太短了，请至少输入10个字');
            textarea.focus();
            return;
        }
        
        try {
            console.log('📝 开始从手动输入生成笔记');
            console.log('输入文字长度:', text.length);
            
            // 使用手动输入的文字
            this.transcribedText = text;
            
            // 显示提示
            if (typeof Utils !== 'undefined' && Utils.showNotification) {
                Utils.showNotification('AI 正在生成笔记...', 'info');
            } else {
                alert('AI 正在生成笔记，请稍候...');
            }
            
            // 调用生成笔记功能
            await this.generateNote();
            
            // 成功后清空输入框
            textarea.value = '';
            
            // 更新字数统计
            const counter = document.getElementById('textCounter');
            if (counter) {
                counter.textContent = '0 字';
                counter.style.color = 'hsl(var(--muted-foreground))';
            }
            
            console.log('✅ 笔记生成完成');
            
        } catch (error) {
            console.error('❌ 生成笔记失败:', error);
            
            if (typeof Utils !== 'undefined' && Utils.showNotification) {
                Utils.showNotification('生成笔记失败: ' + error.message, 'error');
            } else {
                alert('❌ 生成笔记失败: ' + error.message);
            }
        }
    }
}

// 全局变量，方便在 HTML 中调用
let noteManager;

document.addEventListener('DOMContentLoaded', () => {
    noteManager = new NoteAssistantManager();
    console.log('Note Assistant 完全初始化完成');
});
