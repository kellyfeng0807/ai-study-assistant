/**
 * Note Assistant - 基于原版修改，添加百度语音识别
 * 保留原有的文字生成笔记功能
 * 修改：录音后上传到后端使用百度API进行语音识别
 * ✨ 新增：View All 显示所有笔记
 */

class NoteAssistantManager {
    constructor() {
        // 录音相关
        this.isRecording = false;
        this.recordingTime = 0;
        this.timerInterval = null;
        this.mediaRecorder = null;
        this.audioChunks = [];
        this.audioBlob = null;
        
        this.init();
    }
    
    init() {
        this.bindEventListeners();
        this.loadRecentNotes();
        console.log('Note Assistant initialized (使用百度API语音识别)');
    }
    
    bindEventListeners() {
        const recordBtn = document.getElementById('recordBtn');
        const uploadBtn = document.getElementById('uploadBtn');
        const transcribeBtn = document.getElementById('transcribeBtn');
        const manualGenerateBtn = document.getElementById('manualGenerateBtn');
        
        if (recordBtn) {
            recordBtn.addEventListener('click', () => this.toggleRecording());
        }
        
        if (uploadBtn) {
            uploadBtn.addEventListener('click', () => this.uploadAudio());
        }
        
        if (transcribeBtn) {
            transcribeBtn.addEventListener('click', () => this.handleTranscribeOrGenerate());
        }
        
        if (manualGenerateBtn) {
            manualGenerateBtn.addEventListener('click', () => this.generateNoteFromManualInput());
        }
        
        // ✨ 新增：View All 按钮
        const viewAllBtn = document.querySelector('.section-header .link-button');
        if (viewAllBtn) {
            viewAllBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.showAllNotesModal();
            });
        }
    }
    
    async toggleRecording() {
        if (this.isRecording) {
            this.stopRecording();
        } else {
            await this.startRecording();
        }
    }
    
    async startRecording() {
        try {
            const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
            
            this.mediaRecorder = new MediaRecorder(stream, {
                mimeType: 'audio/webm'
            });
            
            this.audioChunks = [];
            
            this.mediaRecorder.ondataavailable = (event) => {
                if (event.data.size > 0) {
                    this.audioChunks.push(event.data);
                }
            };
            
            this.mediaRecorder.onstop = () => {
                this.audioBlob = new Blob(this.audioChunks, { type: 'audio/webm' });
                console.log('✅ 录音完成，大小:', this.audioBlob.size, 'bytes');
                
                const transcribeBtn = document.getElementById('transcribeBtn');
                if (transcribeBtn) {
                    transcribeBtn.disabled = false;
                    transcribeBtn.innerHTML = '<i class="fas fa-file-alt"></i> 转为文字';
                }
                
                Utils.showNotification('录音完成，点击"转为文字"按钮', 'success');
            };
            
            this.mediaRecorder.start();
            this.isRecording = true;
            this.recordingTime = 0;
            
            this.updateRecordingUI();
            this.startTimer();
            
            Utils.showNotification('开始录音...', 'success');
            
        } catch (error) {
            console.error('❌ 录音失败:', error);
            Utils.showNotification('无法访问麦克风: ' + error.message, 'error');
        }
    }
    
    stopRecording() {
        if (this.mediaRecorder && this.isRecording) {
            this.mediaRecorder.stop();
            this.mediaRecorder.stream.getTracks().forEach(track => track.stop());
        }
        
        this.isRecording = false;
        this.stopTimer();
        this.updateRecordingUI();
    }
    
    async handleTranscribeOrGenerate() {
        if (this.audioBlob) {
            await this.transcribeAudio();
        } else {
            const textarea = document.getElementById('manualTextInput');
            if (textarea && textarea.value.trim()) {
                await this.generateNoteFromManualInput();
            } else {
                Utils.showNotification('请先录音或输入文字', 'warning');
            }
        }
    }
    
    async transcribeAudio() {
        if (!this.audioBlob) {
            Utils.showNotification('请先录音', 'warning');
            return;
        }
        
        try {
            console.log('📤 开始上传音频...');
            Utils.showNotification('正在上传音频...', 'info');
            
            const formData = new FormData();
            formData.append('audio', this.audioBlob, 'recording.webm');
            
            const transcribeBtn = document.getElementById('transcribeBtn');
            const originalText = transcribeBtn.innerHTML;
            transcribeBtn.disabled = true;
            transcribeBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> 识别中...';
            
            const response = await fetch('http://localhost:5000/api/note/transcribe', {
                method: 'POST',
                body: formData
            });
            
            const data = await response.json();
            
            if (data.success) {
                console.log('✅ 识别成功:', data.text);
                
                this.fillTextToInputBox(data.text);
                
                Utils.showNotification(`✅ 识别成功！共 ${data.length} 字`, 'success');
                
                this.audioBlob = null;
                this.audioChunks = [];
                
                transcribeBtn.innerHTML = '<i class="fas fa-magic"></i> 生成笔记';
                transcribeBtn.disabled = false;
                
            } else {
                throw new Error(data.error || '识别失败');
            }
            
        } catch (error) {
            console.error('❌ 语音识别失败:', error);
            Utils.showNotification('语音识别失败: ' + error.message, 'error');
            
            const transcribeBtn = document.getElementById('transcribeBtn');
            transcribeBtn.disabled = false;
            transcribeBtn.innerHTML = '<i class="fas fa-file-alt"></i> 转为文字';
        }
    }
    
    fillTextToInputBox(text) {
        if (!text) return;
        
        const textarea = document.getElementById('manualTextInput');
        if (textarea) {
            textarea.value = text;
            
            const counter = document.getElementById('textCounter');
            if (counter) {
                const count = text.trim().length;
                counter.textContent = count + ' 字';
                
                if (count < 10) {
                    counter.style.color = 'hsl(var(--muted-foreground))';
                } else if (count < 50) {
                    counter.style.color = 'hsl(45 93% 47%)';
                } else {
                    counter.style.color = 'hsl(142 76% 36%)';
                }
            }
            
            textarea.scrollIntoView({ behavior: 'smooth', block: 'center' });
            
            textarea.style.transition = 'background-color 0.3s';
            textarea.style.backgroundColor = '#d4edda';
            setTimeout(() => {
                textarea.style.backgroundColor = '';
            }, 800);
            
            console.log('✅ 文字已填充到输入框');
        }
    }
    
    startTimer() {
        this.timerInterval = setInterval(() => {
            this.recordingTime++;
            this.updateTimeDisplay();
        }, 1000);
    }
    
    stopTimer() {
        if (this.timerInterval) {
            clearInterval(this.timerInterval);
            this.timerInterval = null;
        }
    }
    
    updateTimeDisplay() {
        const minutes = Math.floor(this.recordingTime / 60);
        const seconds = this.recordingTime % 60;
        const timeDisplay = document.querySelector('.recording-time');
        if (timeDisplay) {
            timeDisplay.textContent = `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
        }
    }
    
    updateRecordingUI() {
        const recordBtn = document.getElementById('recordBtn');
        const statusDisplay = document.querySelector('.recording-status');
        
        if (this.isRecording) {
            recordBtn.classList.add('recording');
            if (statusDisplay) {
                statusDisplay.textContent = '录音中...';
            }
        } else {
            recordBtn.classList.remove('recording');
            if (statusDisplay) {
                statusDisplay.textContent = this.audioBlob ? '录音完成' : 'Ready to record';
            }
        }
        
        const transcribeBtn = document.getElementById('transcribeBtn');
        if (transcribeBtn) {
            transcribeBtn.disabled = this.isRecording || !this.audioBlob;
        }
    }
    
    uploadAudio() {
        const input = document.createElement('input');
        input.type = 'file';
        input.accept = 'audio/*';
        
        input.onchange = async (e) => {
            const file = e.target.files[0];
            if (!file) return;
            
            console.log('选择的音频文件:', file.name);
            
            this.audioBlob = file;
            
            const transcribeBtn = document.getElementById('transcribeBtn');
            if (transcribeBtn) {
                transcribeBtn.disabled = false;
                transcribeBtn.innerHTML = '<i class="fas fa-file-alt"></i> 转为文字';
            }
            
            Utils.showNotification(`文件已选择: ${file.name}`, 'success');
        };
        
        input.click();
    }
    
    async generateNoteFromManualInput() {
        const textarea = document.getElementById('manualTextInput');
        
        if (!textarea) {
            console.error('找不到文本输入框');
            return;
        }
        
        const text = textarea.value.trim();
        
        if (!text) {
            alert('⚠️ 请输入一些内容');
            textarea.focus();
            return;
        }
        
        if (text.length < 10) {
            alert('⚠️ 内容太短了，请至少输入10个字');
            textarea.focus();
            return;
        }
        
        try {
            console.log('📝 开始生成笔记');
            Utils.showNotification('AI 正在生成笔记...', 'info');
            
            const result = await this.callGenerateAPI(text);
            
            if (result && result.success) {
                console.log('✅ 笔记生成成功');
                Utils.showNotification('笔记生成成功！', 'success');
                
                this.displayGeneratedNote(result.notes);
                
                textarea.value = '';
                const counter = document.getElementById('textCounter');
                if (counter) {
                    counter.textContent = '0 字';
                    counter.style.color = 'hsl(var(--muted-foreground))';
                }
                
                setTimeout(() => this.loadRecentNotes(), 500);
            } else {
                throw new Error(result?.error || '生成笔记失败');
            }
            
        } catch (error) {
            console.error('❌ 生成笔记失败:', error);
            Utils.showNotification('生成笔记失败: ' + error.message, 'error');
        }
    }
    
    async callGenerateAPI(text, subject = '通用') {
        try {
            const response = await fetch('http://localhost:5000/api/note/generate', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    text: text,
                    subject: subject
                })
            });
            
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            
            return await response.json();
        } catch (error) {
            console.error('API 调用失败:', error);
            throw error;
        }
    }
    
    displayGeneratedNote(noteData) {
        const modal = document.createElement('div');
        modal.className = 'note-modal';
        modal.innerHTML = `
            <div class="note-modal-content">
                <div class="note-modal-header">
                    <h3>${noteData.title || '生成的笔记'}</h3>
                    <button class="close-button" onclick="this.closest('.note-modal').remove()">×</button>
                </div>
                <div class="note-modal-body">
                    <div class="note-section">
                        <h4>📚 科目</h4>
                        <p>${noteData.subject}</p>
                    </div>
                    
                    <div class="note-section">
                        <h4>🔑 关键点</h4>
                        <ul>
                            ${noteData.key_points.map(point => `<li>${point}</li>`).join('')}
                        </ul>
                    </div>
                    
                    ${noteData.examples && noteData.examples.length > 0 ? `
                    <div class="note-section">
                        <h4>💡 示例</h4>
                        <ul>
                            ${noteData.examples.map(example => `<li>${example}</li>`).join('')}
                        </ul>
                    </div>
                    ` : ''}
                    
                    <div class="note-section">
                        <h4>📝 总结</h4>
                        <p>${noteData.summary}</p>
                    </div>
                    
                    ${noteData.tags && noteData.tags.length > 0 ? `
                    <div class="note-section">
                        <h4>🏷️ 标签</h4>
                        <div class="note-tags">
                            ${noteData.tags.map(tag => `<span class="note-tag">${tag}</span>`).join('')}
                        </div>
                    </div>
                    ` : ''}
                </div>
            </div>
        `;
        
        document.body.appendChild(modal);
        
        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                modal.remove();
            }
        });
    }
    
    async loadRecentNotes() {
        try {
            const response = await fetch('http://localhost:5000/api/note/list?limit=10');
            const data = await response.json();
            
            if (data.success && data.notes && data.notes.length > 0) {
                console.log('✅ 加载了', data.notes.length, '条笔记');
                this.renderNoteCards(data.notes);
            } else {
                console.log('📝 暂无笔记');
                this.showEmptyState();
            }
        } catch (error) {
            console.error('❌ 加载笔记列表失败:', error);
        }
    }
    
    renderNoteCards(notes) {
        const notesGrid = document.querySelector('.notes-grid');
        if (!notesGrid) {
            console.warn('找不到 .notes-grid 容器');
            return;
        }
        
        notesGrid.innerHTML = '';
        
        const displayNotes = notes.slice(0, 3);
        
        displayNotes.forEach(note => {
            const noteCard = this.createNoteCard(note);
            notesGrid.appendChild(noteCard);
        });
        
        console.log(`📋 已渲染 ${displayNotes.length} 个笔记卡片`);
    }
    
    createNoteCard(note) {
        const card = document.createElement('div');
        card.className = 'note-card';
        
        const date = note.date || new Date().toISOString().split('T')[0];
        const formattedDate = this.formatDate(date);
        
        const keyPointsCount = note.content?.key_points?.length || 0;
        
        card.innerHTML = `
            <div class="note-header">
                <span class="note-subject">${note.subject || '通用'}</span>
                <span class="note-date">${formattedDate}</span>
            </div>
            <h4 class="note-title">${note.title || '未命名笔记'}</h4>
            <p class="note-excerpt">${note.preview || '暂无预览'}</p>
            <div class="note-footer">
                <span class="note-meta">${keyPointsCount} 个关键点</span>
                <button class="button-outline" onclick="noteManager.viewNoteDetail(${note.id})">查看</button>
            </div>
        `;
        
        return card;
    }
    
    formatDate(dateString) {
        const date = new Date(dateString);
        const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
        const month = months[date.getMonth()];
        const day = date.getDate();
        const year = date.getFullYear();
        return `${month} ${day}, ${year}`;
    }
    
    showEmptyState() {
        const notesGrid = document.querySelector('.notes-grid');
        if (!notesGrid) return;
        
        notesGrid.innerHTML = `
            <div style="grid-column: 1 / -1; text-align: center; padding: 40px; color: hsl(var(--muted-foreground));">
                <i class="fas fa-file-alt" style="font-size: 48px; margin-bottom: 16px; opacity: 0.3;"></i>
                <p style="font-size: 16px; margin: 0;">暂无笔记</p>
                <p style="font-size: 14px; margin-top: 8px; opacity: 0.7;">开始录音或输入文字来生成你的第一个笔记吧！</p>
            </div>
        `;
    }
    
    async viewNoteDetail(noteId) {
        try {
            console.log('📖 查看笔记详情:', noteId);
            
            const response = await fetch(`http://localhost:5000/api/note/${noteId}`);
            const data = await response.json();
            
            if (data.success && data.note) {
                this.displayGeneratedNote(data.note.content);
            } else {
                Utils.showNotification('无法加载笔记详情', 'error');
            }
        } catch (error) {
            console.error('加载笔记详情失败:', error);
            Utils.showNotification('加载失败: ' + error.message, 'error');
        }
    }
    
    /**
     * ✨ 新增：显示所有笔记的模态框
     */
    showAllNotesModal() {
        fetch('http://localhost:5000/api/note/list?limit=100')
            .then(response => response.json())
            .then(data => {
                if (data.success && data.notes && data.notes.length > 0) {
                    this.renderAllNotesModal(data.notes);
                } else {
                    Utils.showNotification('暂无笔记', 'info');
                }
            })
            .catch(error => {
                console.error('加载所有笔记失败:', error);
                Utils.showNotification('加载失败', 'error');
            });
    }
    
    /**
     * ✨ 新增：渲染所有笔记模态框
     */
    renderAllNotesModal(notes) {
        const modal = document.createElement('div');
        modal.className = 'note-modal all-notes-modal';
        modal.style.zIndex = '10000';
        
        modal.innerHTML = `
            <div class="note-modal-content" style="max-width: 900px; max-height: 85vh; overflow: hidden; display: flex; flex-direction: column;">
                <div class="note-modal-header" style="flex-shrink: 0;">
                    <h3>📚 所有笔记 (${notes.length})</h3>
                    <button class="close-button" onclick="this.closest('.note-modal').remove()">×</button>
                </div>
                <div class="note-modal-body" style="flex: 1; overflow-y: auto; padding: 20px;">
                    <div class="all-notes-grid" style="display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 16px;">
                        ${notes.map(note => this.createCompactNoteCardHTML(note)).join('')}
                    </div>
                </div>
            </div>
        `;
        
        document.body.appendChild(modal);
        
        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                modal.remove();
            }
        });
        
        modal.querySelectorAll('.view-note-btn').forEach((btn, index) => {
            btn.addEventListener('click', (e) => {
                e.stopPropagation();
                this.viewNoteDetail(notes[index].id);
            });
        });
    }
    
    /**
     * ✨ 新增：创建紧凑型笔记卡片HTML（用于列表）
     */
    createCompactNoteCardHTML(note) {
        const date = note.date || new Date().toISOString().split('T')[0];
        const formattedDate = this.formatDate(date);
        const keyPointsCount = note.content?.key_points?.length || 0;
        
        return `
            <div class="compact-note-card" style="
                background: hsl(var(--card));
                border: 1px solid hsl(var(--border));
                border-radius: 8px;
                padding: 16px;
                cursor: pointer;
                transition: all 0.2s;
            "
            onmouseover="this.style.boxShadow='0 4px 12px rgba(0,0,0,0.1)'; this.style.borderColor='hsl(var(--primary))'"
            onmouseout="this.style.boxShadow=''; this.style.borderColor='hsl(var(--border))'">
                <div style="display: flex; justify-content: space-between; align-items: start; margin-bottom: 8px;">
                    <span style="background: hsl(var(--primary)); color: white; padding: 4px 10px; border-radius: 4px; font-size: 12px; font-weight: 600;">
                        ${note.subject || '通用'}
                    </span>
                    <span style="font-size: 12px; color: hsl(var(--muted-foreground));">
                        ${formattedDate}
                    </span>
                </div>
                <h4 style="font-size: 15px; font-weight: 600; margin: 8px 0; color: hsl(var(--foreground)); line-height: 1.4;">
                    ${note.title || '未命名笔记'}
                </h4>
                <p style="font-size: 13px; color: hsl(var(--muted-foreground)); margin: 8px 0; line-height: 1.5; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;">
                    ${note.preview || '暂无预览'}
                </p>
                <div style="display: flex; justify-content: space-between; align-items: center; margin-top: 12px; padding-top: 12px; border-top: 1px solid hsl(var(--border));">
                    <span style="font-size: 12px; color: hsl(var(--muted-foreground));">
                        ${keyPointsCount} 个关键点
                    </span>
                    <button class="view-note-btn" style="
                        background: transparent;
                        border: 1px solid hsl(var(--primary));
                        color: hsl(var(--primary));
                        padding: 6px 16px;
                        border-radius: 4px;
                        font-size: 12px;
                        cursor: pointer;
                        transition: all 0.2s;
                    "
                    onmouseover="this.style.background='hsl(var(--primary))'; this.style.color='white'"
                    onmouseout="this.style.background='transparent'; this.style.color='hsl(var(--primary))'">
                        查看
                    </button>
                </div>
            </div>
        `;
    }
}

let noteManager;

document.addEventListener('DOMContentLoaded', () => {
    noteManager = new NoteAssistantManager();
    console.log('Note Assistant 初始化完成（使用百度API + View All）');
});