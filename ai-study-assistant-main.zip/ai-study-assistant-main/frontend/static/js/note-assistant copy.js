/**
 * Note Assistant - 使用后端 API 进行语音转文字
 * 不再依赖 Web Speech API
 * ✅ 已修复：数据结构匹配问题
 */

class NoteAssistantManager {
    constructor() {
        // 录音相关
        this.isRecording = false;
        this.recordingTime = 0;
        this.timerInterval = null;
        this.mediaRecorder = null;
        this.audioChunks = [];
        this.audioBlob = null;  // 保存录制的音频
        
        // 初始化
        this.init();
    }
    
    init() {
        this.bindEventListeners();
        this.loadRecentNotes();
        console.log('Note Assistant initialized (使用后端 API 语音识别)');
    }
    
    bindEventListeners() {
        const recordBtn = document.getElementById('recordBtn');
        const uploadBtn = document.getElementById('uploadBtn');
        const transcribeBtn = document.getElementById('transcribeBtn');
        const manualGenerateBtn = document.getElementById('manualGenerateBtn');
        
        if (recordBtn) {
            recordBtn.addEventListener('click', () => this.toggleRecording());
        }
        
        if (uploadBtn) {
            uploadBtn.addEventListener('click', () => this.uploadAudio());
        }
        
        if (transcribeBtn) {
            transcribeBtn.addEventListener('click', () => this.transcribeAudio());
        }
        
        if (manualGenerateBtn) {
            manualGenerateBtn.addEventListener('click', () => this.generateNoteFromManualInput());
        }
    }
    
    toggleRecording() {
        if (this.isRecording) {
            this.stopRecording();
        } else {
            this.startRecording();
        }
    }
    
    async startRecording() {
        try {
            const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
            
            this.mediaRecorder = new MediaRecorder(stream, {
                mimeType: 'audio/webm'
            });
            
            this.audioChunks = [];
            
            this.mediaRecorder.ondataavailable = (event) => {
                if (event.data.size > 0) {
                    this.audioChunks.push(event.data);
                }
            };
            
            this.mediaRecorder.onstop = () => {
                this.audioBlob = new Blob(this.audioChunks, { type: 'audio/webm' });
                console.log('✅ 录音完成，大小:', this.audioBlob.size, 'bytes');
                
                const transcribeBtn = document.getElementById('transcribeBtn');
                if (transcribeBtn) {
                    transcribeBtn.disabled = false;
                    transcribeBtn.innerHTML = '<i class="fas fa-file-alt"></i> 转为文字';
                }
                
                Utils.showNotification('录音完成，点击"转为文字"按钮', 'success');
            };
            
            this.mediaRecorder.start();
            this.isRecording = true;
            this.recordingTime = 0;
            
            this.updateRecordingUI();
            this.startTimer();
            
            Utils.showNotification('开始录音...', 'success');
            
        } catch (error) {
            console.error('❌ 录音失败:', error);
            Utils.showNotification('无法访问麦克风: ' + error.message, 'error');
        }
    }
    
    stopRecording() {
        if (this.mediaRecorder && this.isRecording) {
            this.mediaRecorder.stop();
            this.mediaRecorder.stream.getTracks().forEach(track => track.stop());
        }
        
        this.isRecording = false;
        this.stopTimer();
        this.updateRecordingUI();
    }
    
    async transcribeAudio() {
        if (!this.audioBlob) {
            Utils.showNotification('请先录音', 'warning');
            return;
        }
        
        try {
            console.log('📤 开始上传音频...');
            Utils.showNotification('正在上传音频...', 'info');
            
            const formData = new FormData();
            formData.append('audio', this.audioBlob, 'recording.webm');
            
            const transcribeBtn = document.getElementById('transcribeBtn');
            const originalText = transcribeBtn.innerHTML;
            transcribeBtn.disabled = true;
            transcribeBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> 识别中...';
            
            const response = await fetch('http://localhost:5000/api/note/transcribe', {
                method: 'POST',
                body: formData
            });
            
            const data = await response.json();
            
            if (data.success) {
                console.log('✅ 识别成功:', data.text);
                
                this.fillTextToInputBox(data.text);
                
                Utils.showNotification(`✅ 识别成功！共 ${data.length} 字`, 'success');
                
                this.audioBlob = null;
                this.audioChunks = [];
                
                transcribeBtn.innerHTML = '<i class="fas fa-file-alt"></i> 生成笔记';
                transcribeBtn.disabled = false;
                
            } else {
                throw new Error(data.error || '识别失败');
            }
            
        } catch (error) {
            console.error('❌ 语音识别失败:', error);
            Utils.showNotification('语音识别失败: ' + error.message, 'error');
            
            const transcribeBtn = document.getElementById('transcribeBtn');
            transcribeBtn.disabled = false;
            transcribeBtn.innerHTML = '<i class="fas fa-file-alt"></i> 转为文字';
        }
    }
    
    fillTextToInputBox(text) {
        if (!text) return;
        
        const textarea = document.getElementById('manualTextInput');
        if (textarea) {
            textarea.value = text;
            
            const counter = document.getElementById('textCounter');
            if (counter) {
                const count = text.trim().length;
                counter.textContent = count + ' 字';
                
                if (count < 10) {
                    counter.style.color = 'hsl(var(--muted-foreground))';
                } else if (count < 50) {
                    counter.style.color = 'hsl(45 93% 47%)';
                } else {
                    counter.style.color = 'hsl(142 76% 36%)';
                }
            }
            
            textarea.scrollIntoView({ behavior: 'smooth', block: 'center' });
            
            textarea.style.transition = 'background-color 0.3s';
            textarea.style.backgroundColor = '#d4edda';
            setTimeout(() => {
                textarea.style.backgroundColor = '';
            }, 800);
            
            console.log('✅ 文字已填充到输入框');
        }
    }
    
    startTimer() {
        this.timerInterval = setInterval(() => {
            this.recordingTime++;
            this.updateTimeDisplay();
        }, 1000);
    }
    
    stopTimer() {
        if (this.timerInterval) {
            clearInterval(this.timerInterval);
            this.timerInterval = null;
        }
    }
    
    updateTimeDisplay() {
        const minutes = Math.floor(this.recordingTime / 60);
        const seconds = this.recordingTime % 60;
        const timeDisplay = document.querySelector('.recording-time');
        if (timeDisplay) {
            timeDisplay.textContent = `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
        }
    }
    
    updateRecordingUI() {
        const recordBtn = document.getElementById('recordBtn');
        const statusDisplay = document.querySelector('.recording-status');
        
        if (this.isRecording) {
            recordBtn.classList.add('recording');
            if (statusDisplay) {
                statusDisplay.textContent = '录音中...';
            }
        } else {
            recordBtn.classList.remove('recording');
            if (statusDisplay) {
                statusDisplay.textContent = this.audioBlob ? '录音完成' : 'Ready to record';
            }
        }
        
        const transcribeBtn = document.getElementById('transcribeBtn');
        if (transcribeBtn) {
            transcribeBtn.disabled = this.isRecording || !this.audioBlob;
        }
    }
    
    uploadAudio() {
        const input = document.createElement('input');
        input.type = 'file';
        input.accept = 'audio/*';
        
        input.onchange = async (e) => {
            const file = e.target.files[0];
            if (!file) return;
            
            console.log('选择的音频文件:', file.name);
            
            this.audioBlob = file;
            
            const transcribeBtn = document.getElementById('transcribeBtn');
            if (transcribeBtn) {
                transcribeBtn.disabled = false;
                transcribeBtn.innerHTML = '<i class="fas fa-file-alt"></i> 转为文字';
            }
            
            Utils.showNotification(`文件已选择: ${file.name}`, 'success');
        };
        
        input.click();
    }
    
    /**
     * ✅ 修复：从手动输入生成笔记
     */
    async generateNoteFromManualInput() {
        const textarea = document.getElementById('manualTextInput');
        
        if (!textarea) {
            console.error('找不到文本输入框');
            return;
        }
        
        const text = textarea.value.trim();
        
        if (!text) {
            alert('⚠️ 请输入一些内容');
            textarea.focus();
            return;
        }
        
        if (text.length < 10) {
            alert('⚠️ 内容太短了，请至少输入10个字');
            textarea.focus();
            return;
        }
        
        try {
            console.log('📝 开始生成笔记');
            Utils.showNotification('AI 正在生成笔记...', 'info');
            
            const response = await fetch('http://localhost:5000/api/note/generate', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    text: text
                })
            });
            
            const data = await response.json();
            console.log('📥 后端返回:', data);
            
            if (data.success) {
                console.log('✅ 笔记生成成功');
                
                // ✅ 修复：后端返回的是 data.notes，不是 data.note
                this.displayGeneratedNote(data.notes);
                
                // 清空输入框
                textarea.value = '';
                const counter = document.getElementById('textCounter');
                if (counter) {
                    counter.textContent = '0 字';
                    counter.style.color = 'hsl(var(--muted-foreground))';
                }
                
                Utils.showNotification('笔记生成成功！', 'success');
            } else {
                throw new Error(data.error || '生成失败');
            }
            
        } catch (error) {
            console.error('❌ 生成笔记失败:', error);
            Utils.showNotification('生成笔记失败: ' + error.message, 'error');
        }
    }
    
    /**
     * ✅ 修复：显示生成的笔记（使用正确的数据结构）
     */
    displayGeneratedNote(notes) {
        if (!notes) {
            console.error('笔记数据为空');
            return;
        }
        
        console.log('显示笔记:', notes);
        
        // 构建笔记内容显示
        let content = `📋 笔记已生成！\n\n`;
        content += `标题: ${notes.title || '未命名'}\n\n`;
        content += `科目: ${notes.subject || '通用'}\n\n`;
        
        if (notes.summary) {
            content += `📝 总结:\n${notes.summary}\n\n`;
        }
        
        if (notes.key_points && notes.key_points.length > 0) {
            content += `🔑 关键点:\n`;
            notes.key_points.forEach((point, index) => {
                content += `${index + 1}. ${point}\n`;
            });
            content += `\n`;
        }
        
        if (notes.examples && notes.examples.length > 0) {
            content += `💡 示例:\n`;
            notes.examples.forEach((example, index) => {
                content += `${index + 1}. ${example}\n`;
            });
            content += `\n`;
        }
        
        if (notes.tags && notes.tags.length > 0) {
            content += `🏷️ 标签: ${notes.tags.join(', ')}`;
        }
        
        // 使用 alert 显示（临时方案，未来可以改成模态框）
        alert(content);
    }
    
    async loadRecentNotes() {
        console.log('加载最近笔记...');
    }
}

// 全局变量
let noteManager;

document.addEventListener('DOMContentLoaded', () => {
    noteManager = new NoteAssistantManager();
    console.log('Note Assistant 初始化完成（使用后端 API）');
});