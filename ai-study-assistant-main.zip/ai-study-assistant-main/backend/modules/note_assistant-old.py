"""
Note Assistant Module - 使用百度语音识别（免费）
完全支持人民币支付，每天 50,000 次免费调用
"""

from flask import Blueprint, request, jsonify
import os
import json
from datetime import datetime
import requests
import tempfile
from werkzeug.utils import secure_filename
from dotenv import load_dotenv  # ✅ 添加这行

# ✅ 加载环境变量（必须在 os.getenv 之前！）
load_dotenv()

note_bp = Blueprint('note_assistant', __name__, url_prefix='/api/note')

# ============== 百度语音识别配置 ==============
'''
# ✅ 这些应该已经有了
BAIDU_APP_ID = os.getenv('BAIDU_APP_ID')
BAIDU_API_KEY = os.getenv('BAIDU_API_KEY')
BAIDU_SECRET_KEY = os.getenv('BAIDU_SECRET_KEY')

# DeepSeek API 配置
DEEPSEEK_API_KEY = os.getenv('DEEPSEEK_API_KEY')
DEEPSEEK_BASE_URL = "https://api.deepseek.com/v1"
'''
#临时方案：直接硬编码（仅用于测试）
BAIDU_APP_ID = '7227061'
BAIDU_API_KEY = 'MuZYealXv5pwVZsK3tFkWTwe'
BAIDU_SECRET_KEY = 'zdAvuWkk4aLtefGiILuQb35gcqK7fvz7'
DEEPSEEK_API_KEY = 'sk-d2872eac86d849f4acd666439608c963'
DEEPSEEK_BASE_URL = "https://api.deepseek.com/v1"

# ✅ 建议添加：调试输出
print("=== 环境变量检查 ===")
print(f"📋 BAIDU_APP_ID: {BAIDU_APP_ID}")
print(f"📋 BAIDU_API_KEY: {'已配置' if BAIDU_API_KEY else '未配置'}")
print(f"📋 BAIDU_SECRET_KEY: {'已配置' if BAIDU_SECRET_KEY else '未配置'}")
print(f"📋 DEEPSEEK_API_KEY: {'已配置' if DEEPSEEK_API_KEY else '未配置'}")
print("===================")

# 百度语音识别客户端（懒加载）
baidu_client = None

def get_baidu_client():
    """获取百度语音识别客户端"""
    global baidu_client
    if baidu_client is None and all([BAIDU_APP_ID, BAIDU_API_KEY, BAIDU_SECRET_KEY]):
        try:
            from aip import AipSpeech
            baidu_client = AipSpeech(BAIDU_APP_ID, BAIDU_API_KEY, BAIDU_SECRET_KEY)
            print("✅ 百度语音识别客户端初始化成功")
        except ImportError:
            print("⚠️ 请安装百度 SDK: pip install baidu-aip")
        except Exception as e:
            print(f"⚠️ 百度客户端初始化失败: {e}")
    return baidu_client

# DeepSeek API 配置
DEEPSEEK_API_KEY = os.getenv('DEEPSEEK_API_KEY')
DEEPSEEK_BASE_URL = "https://api.deepseek.com/v1"

# 允许的音频格式
ALLOWED_AUDIO_EXTENSIONS = {'mp3', 'wav', 'pcm', 'webm', 'm4a'}

# 笔记存储
notes_storage = []


def allowed_audio_file(filename):
    """检查音频文件格式"""
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_AUDIO_EXTENSIONS


def convert_audio_format(input_path, output_format='wav'):
    """
    转换音频格式（如果需要）
    百度要求：PCM、WAV、AMR格式，采样率 16000
    """
    try:
        import subprocess
        
        # 生成输出文件路径
        output_path = input_path.rsplit('.', 1)[0] + f'.{output_format}'
        
        # 使用 ffmpeg 转换
        # 如果没有 ffmpeg，这个函数会失败，但不影响主流程
        cmd = [
            'ffmpeg', '-i', input_path,
            '-ar', '16000',  # 采样率 16000
            '-ac', '1',       # 单声道
            '-y',             # 覆盖输出文件
            output_path
        ]
        
        subprocess.run(cmd, capture_output=True, check=True)
        return output_path
    except Exception as e:
        print(f"⚠️ 音频转换失败（可能没有安装 ffmpeg）: {e}")
        return input_path  # 返回原文件


# ============== ✨ 语音转文字接口（百度） ==============

@note_bp.route('/transcribe', methods=['POST'])
def transcribe_audio():
    """
    语音转文字接口 - 使用百度语音识别（免费）
    每天 50,000 次免费调用
    """
    try:
        # 检查百度客户端
        client = get_baidu_client()
        if not client:
            return jsonify({
                'success': False,
                'error': '百度语音识别未配置。请在 .env 文件中设置 BAIDU_APP_ID, BAIDU_API_KEY, BAIDU_SECRET_KEY'
            }), 503
        
        # 检查文件
        if 'audio' not in request.files:
            return jsonify({
                'success': False,
                'error': '没有上传音频文件'
            }), 400
        
        audio_file = request.files['audio']
        
        if audio_file.filename == '':
            return jsonify({
                'success': False,
                'error': '文件名为空'
            }), 400
        
        if not allowed_audio_file(audio_file.filename):
            return jsonify({
                'success': False,
                'error': f'不支持的文件格式，支持：{", ".join(ALLOWED_AUDIO_EXTENSIONS)}'
            }), 400
        
        # 保存临时文件
        filename = secure_filename(audio_file.filename)
        temp_dir = tempfile.gettempdir()
        temp_path = os.path.join(temp_dir, filename)
        audio_file.save(temp_path)
        
        print(f'📁 音频文件已保存: {temp_path}')
        print(f'📊 文件大小: {os.path.getsize(temp_path)} bytes')
        
        # 转换为 WAV 格式（百度推荐）
        try:
            wav_path = convert_audio_format(temp_path, 'wav')
            print(f'🔄 音频已转换为 WAV: {wav_path}')
        except:
            wav_path = temp_path
            print('⚠️ 使用原始音频文件（未转换）')
        
        # 读取音频数据
        with open(wav_path, 'rb') as f:
            audio_data = f.read()
        
        # 调用百度语音识别 API
        print('🎤 开始调用百度语音识别 API...')
        result = client.asr(
            audio_data,
            'wav',   # 格式
            16000,   # 采样率
            {
                'dev_pid': 1537  # 1537 表示普通话（纯中文识别）
                                 # 1737 英语
                                 # 1837 粤语
                                 # 1936 四川话
            }
        )
        
        # 处理结果
        if result.get('err_no') == 0:
            # 识别成功
            transcribed_text = ''.join(result.get('result', []))
            print(f'✅ 识别成功: {transcribed_text[:100]}...')
            
            # 清理临时文件
            os.remove(temp_path)
            if wav_path != temp_path and os.path.exists(wav_path):
                os.remove(wav_path)
            print('🗑️ 临时文件已删除')
            
            return jsonify({
                'success': True,
                'text': transcribed_text,
                'length': len(transcribed_text)
            })
        else:
            # 识别失败
            error_msg = result.get('err_msg', '未知错误')
            print(f'❌ 百度识别失败: {error_msg}')
            
            # 清理临时文件
            os.remove(temp_path)
            if wav_path != temp_path and os.path.exists(wav_path):
                os.remove(wav_path)
            
            return jsonify({
                'success': False,
                'error': f'语音识别失败: {error_msg}'
            }), 500
        
    except Exception as e:
        print(f'❌ 语音转文字失败: {str(e)}')
        
        # 清理临时文件
        if 'temp_path' in locals() and os.path.exists(temp_path):
            os.remove(temp_path)
        if 'wav_path' in locals() and wav_path != temp_path and os.path.exists(wav_path):
            os.remove(wav_path)
        
        return jsonify({
            'success': False,
            'error': f'语音转文字失败: {str(e)}'
        }), 500


# ============== 原有的笔记生成接口（保持不变）==============

@note_bp.route('/generate', methods=['POST'])
def generate_notes():
    """
    生成结构化笔记
    使用 DeepSeek LLM 提取关键点和示例
    """
    try:
        data = request.json
        text = data.get('text', '')
        subject = data.get('subject', '通用')
        
        if not text or len(text.strip()) < 10:
            return jsonify({'error': 'Text too short for note generation'}), 400
        
        # 构建 Prompt
        prompt = f"""请将以下内容整理成结构化的学习笔记。

原始内容：
{text}

请按照以下格式输出JSON：
{{
    "title": "笔记标题",
    "subject": "{subject}",
    "key_points": ["关键点1", "关键点2", "关键点3"],
    "examples": ["示例1", "示例2"],
    "summary": "内容总结（50-100字）",
    "tags": ["标签1", "标签2"]
}}

要求：
1. 提取3-5个关键知识点
2. 如果有例子，提取1-3个代表性示例
3. 生成简洁的总结
4. 添加2-3个相关标签
5. 只返回JSON，不要其他文字"""

        # 调用 DeepSeek API
        if DEEPSEEK_API_KEY:
            headers = {
                "Authorization": f"Bearer {DEEPSEEK_API_KEY}",
                "Content-Type": "application/json"
            }
            
            payload = {
                "model": "deepseek-chat",
                "messages": [
                    {"role": "system", "content": "你是一个专业的学习笔记助手，擅长提取关键信息并生成结构化笔记。"},
                    {"role": "user", "content": prompt}
                ],
                "temperature": 0.7,
                "max_tokens": 2000
            }
            
            try:
                response = requests.post(
                    f"{DEEPSEEK_BASE_URL}/chat/completions",
                    headers=headers,
                    json=payload,
                    timeout=30
                )
                
                if response.status_code == 200:
                    result = response.json()
                    content = result['choices'][0]['message']['content']
                    
                    # 解析 JSON
                    try:
                        if '```json' in content:
                            content = content.split('```json')[1].split('```')[0].strip()
                        elif '```' in content:
                            content = content.split('```')[1].split('```')[0].strip()
                        
                        notes_data = json.loads(content)
                    except json.JSONDecodeError:
                        notes_data = create_fallback_notes(text, subject)
                else:
                    print(f"DeepSeek API error: {response.status_code}")
                    notes_data = create_fallback_notes(text, subject)
            except Exception as e:
                print(f"DeepSeek API request failed: {e}")
                notes_data = create_fallback_notes(text, subject)
        else:
            notes_data = create_fallback_notes(text, subject)
        
        # 保存笔记
        note_id = len(notes_storage) + 1
        note_record = {
            'id': note_id,
            'title': notes_data.get('title', '未命名笔记'),
            'subject': notes_data.get('subject', subject),
            'date': datetime.now().strftime('%Y-%m-%d'),
            'content': notes_data,
            'original_text': text
        }
        notes_storage.append(note_record)
        
        return jsonify({
            'success': True,
            'note_id': note_id,
            'notes': notes_data
        })
    
    except Exception as e:
        print(f"Error in generate_notes: {e}")
        return jsonify({'error': str(e)}), 500


@note_bp.route('/list', methods=['GET'])
def list_notes():
    """获取笔记列表"""
    try:
        subject = request.args.get('subject', None)
        limit = int(request.args.get('limit', 10))
        
        filtered_notes = notes_storage
        if subject:
            filtered_notes = [n for n in notes_storage if n['subject'] == subject]
        
        notes_list = [
            {
                'id': note['id'],
                'title': note['title'],
                'subject': note['subject'],
                'date': note['date'],
                'preview': note['content'].get('summary', '')[:100]
            }
            for note in filtered_notes[-limit:]
        ]
        
        return jsonify({
            'success': True,
            'total': len(filtered_notes),
            'notes': notes_list[::-1]
        })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@note_bp.route('/<int:note_id>', methods=['GET'])
def get_note_detail(note_id):
    """获取笔记详情"""
    try:
        note = next((n for n in notes_storage if n['id'] == note_id), None)
        
        if not note:
            return jsonify({'error': 'Note not found'}), 404
        
        return jsonify({
            'success': True,
            'note': note
        })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@note_bp.route('/<int:note_id>', methods=['DELETE'])
def delete_note(note_id):
    """删除笔记"""
    try:
        global notes_storage
        original_length = len(notes_storage)
        notes_storage = [n for n in notes_storage if n['id'] != note_id]
        
        if len(notes_storage) == original_length:
            return jsonify({'error': 'Note not found'}), 404
        
        return jsonify({
            'success': True,
            'message': 'Note deleted successfully'
        })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500


def create_fallback_notes(text, subject):
    """Fallback 笔记生成"""
    sentences = [s.strip() for s in text.split('。') if s.strip()]
    key_points = sentences[:min(3, len(sentences))]
    title = sentences[0][:15] + "..." if sentences else "笔记"
    summary = text[:100] + "..." if len(text) > 100 else text
    
    return {
        'title': title,
        'subject': subject,
        'key_points': key_points,
        'examples': [],
        'summary': summary,
        'tags': [subject, '学习笔记']
    }


@note_bp.route('/health', methods=['GET'])
def health_check():
    """API 健康检查"""
    client = get_baidu_client()
    return jsonify({
        'status': 'healthy',
        'module': 'note_assistant',
        'baidu_available': client is not None,
        'deepseek_available': bool(DEEPSEEK_API_KEY),
        'total_notes': len(notes_storage)
    })